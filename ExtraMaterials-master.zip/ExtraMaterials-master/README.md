# ExtraMaterials

These are additional materials for the class. They do not strictly follow the content of the lectures, and are not required for completing the assignments, however they are potentially useful materials for Data Science / Programming more generally, and may be useful for your projects. 


## Some Useful External Links
If you are moving to Python from Matlab, check out this 'CheatSheet':
- http://mathesaurus.sourceforge.net/matlab-numpy.html
