# Assignments

All assignments and section materials use Python3.6, with the anaconda distrition, without any extra dependencies. 
